export const PredictionTable = ({ data }) => (
  <div className="bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden text-sm">
    <table className="w-full text-left">
      <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold border-b border-slate-200">
        <tr>
          <th className="p-4">Tanggal</th>
          <th className="p-4 text-center">Confidence level</th>
          {/* <th className="p-4">Harga penutupan</th>
          <th className="p-4">Harga penutupan selanjutnya</th> */}
          <th className="p-4">Aktual</th>
          <th className="p-4">Prediksi</th>
          <th className="p-4">Hasil</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {data.map((item, index) => (
          <tr
            key={index}
            className="hover:bg-slate-50/50 transition text-slate-700"
          >
            <td className="p-4 font-medium">{item.date}</td>

            <td className="p-4 text-center">
              <div className="w-24 bg-slate-200 h-1.5 rounded-full mx-auto overflow-hidden">
                <div
                  className="bg-blue-600 h-1.5 rounded-full"
                  style={{ width: `${item.confidence}%` }}
                ></div>
              </div>
            </td>
            {/* <td className="p-4 font-mono font-bold">${item.target}</td>
            <td className="p-4 font-mono font-bold">${item.target}</td> */}
            <td
              className={`p-4 font-bold ${
                item.trend === "UP" ? "text-emerald-600" : "text-red-600"
              }`}
            >
              <i
                className={`fa-solid ${
                  item.trend === "UP"
                    ? "fa-arrow-trend-up"
                    : "fa-arrow-trend-down"
                } mr-2`}
              ></i>
              {item.trend}
            </td>
            <td
              className={`p-4 font-bold ${
                item.trend === "UP" ? "text-emerald-600" : "text-red-600"
              }`}
            >
              <i
                className={`fa-solid ${
                  item.trend === "UP"
                    ? "fa-arrow-trend-up"
                    : "fa-arrow-trend-down"
                } mr-2`}
              ></i>
              {item.trend}
            </td>
            <td className="p-4">
              <span
                className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                  item.isCorrect
                    ? "bg-emerald-100 text-emerald-700"
                    : "bg-red-100 text-red-700"
                }`}
              >
                <i
                  className={`fa-solid ${
                    item.isCorrect ? "fa-check" : "fa-xmark"
                  } mr-1`}
                ></i>
                {item.isCorrect ? "Benar" : "Salah"}
              </span>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

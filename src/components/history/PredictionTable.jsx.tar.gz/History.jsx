import { StatCard } from "../components/dashboard/StatCard";
import { PredictionTable } from "../components/dashboard/PredictionTable";
import { PredictionSummary } from "../components/dashboard/PredictionSummary";

export default function History() {
  const dummyHistory = [
    {
      date: "25 Jan 26",
      trend: "UP",
      confidence: 87,
      target: "96,500",
      isCorrect: true,
    },
    {
      date: "22 Jan 26",
      trend: "DOWN",
      confidence: 78,
      target: "93,000",
      isCorrect: false,
    },
    {
      date: "20 Jan 26",
      trend: "UP",
      confidence: 92,
      target: "91,000",
      isCorrect: true,
    },
  ];

  // Logic Sederhana untuk Summary
  const totalPred = dummyHistory.length;
  const totalCorrect = dummyHistory.filter((item) => item.isCorrect).length;
  const avgConfidence = (
    dummyHistory.reduce((acc, curr) => acc + curr.confidence, 0) / totalPred
  ).toFixed(1);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 space-y-8">
      {/* Row 1: Stats */}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <h3 className="text-lg font-bold mb-4 text-slate-900">
            Riwayat Prediksi
          </h3>
          <PredictionTable data={dummyHistory} />
        </div>
      </div>
    </div>
  );
}
